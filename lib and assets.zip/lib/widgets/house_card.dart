// widgets/house_card.dart
import 'package:flutter/material.dart';
import '../models/house.dart';

class HouseCard extends StatelessWidget {
  final House house;
  final VoidCallback onTap;

  const HouseCard({
    super.key,
    required this.house,
    required this.onTap,
  });

  // ويدجيت مساعدة لعرض تفاصيل (مثل غرف النوم والحمامات)
  Widget _buildFeatureRow(int beds, int baths, double area) {
    // يمكن تكييف هذه الرموز لتكون أيقونات Flutter Icons
    return Row(
      children: [
        const Icon(Icons.bed, size: 16, color: Colors.grey),
        const SizedBox(width: 4),
        Text('${beds} bedrooms', style: const TextStyle(fontSize: 14, color: Colors.grey)),
        const SizedBox(width: 16),
        const Icon(Icons.bathtub, size: 16, color: Colors.grey),
        const SizedBox(width: 4),
        Text('${baths} bathrooms', style: const TextStyle(fontSize: 14, color: Colors.grey)),
        const SizedBox(width: 16),
        const Icon(Icons.square_foot, size: 16, color: Colors.grey),
        const SizedBox(width: 4),
        Text('${area} sqft', style: const TextStyle(fontSize: 14, color: Colors.grey)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20), // حواف مستديرة
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 2,
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // صورة المنزل
       // في ملف HouseCard
// ...
            // صورة المنزل
            ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              child: Image.asset( // 🚨 تم التغيير إلى Image.asset
                house.image,
                height: 200,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
// ...

            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // السعر
                  Text(
                    '\$${house.price.toInt()}',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 4),

                  // العنوان (يمكن استبداله بـ Address)
                  Text(
                    house.address,
                    style: const TextStyle(
                      fontSize: 16,
                      color: Colors.grey,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 8),

                  // تفاصيل الغرف والحمامات والمساحة
                  _buildFeatureRow(house.beds, house.baths, house.area),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}