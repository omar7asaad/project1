// models/house.dart
class House {
  String title;
  String address;
  String image;
  double price;
  int beds;
  int baths;
  double area;
  // 🚨 إضافة حقل الوصف
  String description;

  House({
    required this.title,
    required this.address,
    required this.image,
    required this.price,
    required this.beds,
    required this.baths,
    required this.area,
    // 🚨 إضافة متطلب الوصف
    required this.description,
  });
}