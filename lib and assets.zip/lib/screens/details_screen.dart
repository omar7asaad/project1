// screens/details_screen.dart
import 'package:flutter/material.dart';
import '../models/house.dart';

class DetailsScreen extends StatelessWidget {
  final House house;

  const DetailsScreen({super.key, required this.house});

  // ويدجيت مساعدة لعرض بطاقات المواصفات (المساحة، الغرف، الحمامات)
  Widget _buildSpecCard(String value, String label) {
    return Container(
      width: 100, // تحديد عرض ثابت
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            value,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            label,
            style: const TextStyle(
              fontSize: 12,
              color: Colors.grey,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,

      // الـ AppBar الشفاف فوق الصورة
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.favorite_border, color: Colors.white),
            onPressed: () {},
          ),
        ],
      ),

      body: Stack(
        children: [
          // 1. الصورة الرئيسية
          Image.asset(
            house.image,
            height: MediaQuery.of(context).size.height * 0.55,
            width: double.infinity,
            fit: BoxFit.cover,
          ),

          // 2. المحتوى السفلي الأبيض (شكل ورقة بيضاء عائمة)
          Positioned.fill(
            // 🚨 التصحيح هنا: نجعله يبدأ من 40% من الأعلى ليعطي مجالاً للصور والتفاصيل
          top: MediaQuery.of(context).size.height * 0.40,
            child: Container(
              padding: const EdgeInsets.only(top: 20),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
              ),
              child: SingleChildScrollView(
                // ترك مساحة سفلية لعدم تداخل المحتوى مع زر الحجز
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 120),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // السعر والوقت
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          '\$${house.price.toInt()}',
                          style: const TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const Text(
                          'منذ 30 ساعة',
                          style: TextStyle(color: Colors.grey),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      house.address,
                      style: const TextStyle(fontSize: 16, color: Colors.grey),
                    ),

                    const SizedBox(height: 20),
                    const Text(
                      'معلومات العقار',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // بطاقات المواصفات
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildSpecCard('${house.area} م²', 'المساحة'),
                        _buildSpecCard('${house.beds}', 'غرف النوم'),
                        _buildSpecCard('${house.baths}', 'الحمامات'),
                      ],
                    ),

                    const SizedBox(height: 20),

                    // الوصف - الآن يستخدم حقل description من الموديل
                    Text(
                      house.description, // 🚨 هذا هو السطر الذي يعرض الوصف
                      style: const TextStyle(fontSize: 16, height: 1.5),
                      textAlign: TextAlign.justify,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),

      // 3. زر "احجز الآن" الثابت في الأسفل
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black12.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: SizedBox(
          height: 50,
          width: double.infinity,
          child: ElevatedButton(
            onPressed: () {
              // إضافة منطق الحجز هنا
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.black87,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
            ),
            child: const Text(
              'احجز الآن',
              style: TextStyle(
                fontSize: 18,
                color: Colors.white,
                fontWeight: FontWeight.bold
              ),
            ),
          ),
        ),
      ),
    );
  }
}