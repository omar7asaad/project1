// screens/home_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/house_controller.dart';
import '../widgets/house_card.dart';
import 'details_screen.dart';

class HomeScreen extends StatelessWidget {
  final HouseController controller = Get.put(HouseController());

  HomeScreen({super.key});

  // ويدجيت لزر الفلتر
  Widget _buildFilterChip(String label, {bool isSelected = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      margin: const EdgeInsets.only(right: 8),
      decoration: BoxDecoration(
        color: isSelected ? Colors.black87 : Colors.grey.shade200,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: isSelected ? Colors.white : Colors.black87,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        // إزالة App Bar التقليدي واستبداله بتصميم مخصص
        backgroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 0, // لإزالة الـ AppBar بالكامل
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // شريط العنوان العلوي والأيقونات
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Icon(Icons.tune, size: 28), // أيقونة الفلتر
                const Text(
                  'تطبيق العقارات', // تعريب العنوان
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)
                ),
                const Icon(Icons.show_chart, size: 28), // أيقونة إحصائيات
              ],
            ),
          ),

          // حقل المدينة
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0),
            child: Text('المدينة', style: TextStyle(color: Colors.grey, fontSize: 16)), // تعريب
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(16, 4, 16, 12),
            child: Text(
              'دمشق', // 🚨 تم التعديل إلى 'دمشق'
              style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
            ),
          ),

          // الفلاتر الأفقية (تم تعريب محتوى الأزرار)
          Container(
            height: 50,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _buildFilterChip('أقل من 220 ألف', isSelected: true),
                _buildFilterChip('للبيع'),
                _buildFilterChip('3-4 غرف نوم'),
                _buildFilterChip('مع كراج'),
              ],
            ),
          ),
          const SizedBox(height: 10),

          // قائمة المنازل
          Expanded(
            child: Obx(
              () => ListView.builder(
                padding: const EdgeInsets.only(top: 8, bottom: 80),
                itemCount: controller.houses.length,
                itemBuilder: (context, index) {
                  final house = controller.houses[index];
                  return HouseCard(
                    house: house,
                    onTap: () {
                      Get.to(() => DetailsScreen(house: house));
                    },
                  );
                },
              ),
            ),
          ),
        ],
      ),

      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
    );
  }
}