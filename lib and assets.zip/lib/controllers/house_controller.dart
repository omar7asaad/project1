// controllers/house_controller.dart

import 'package:get/get.dart';
import '../models/house.dart';

class HouseController extends GetxController {
  var houses = <House>[
    House(
      title: 'شقة فاخرة بإطلالة بحرية',
      address: 'اللاذقية - مشروع ب',
      image: 'assets/images/house1.jpeg',
      price: 185000,
      beds: 4,
      baths: 3,
      area: 220,
      // 🚨 الوصف الأول
      description: 'شقة واسعة ومشرقة في الطابق الخامس، تطل مباشرة على البحر الأبيض المتوسط. التشطيبات سوبر ديلوكس مع نظام تدفئة مركزي وموقف سيارات خاص. مثالية للعائلات الكبيرة.',
    ),
    House(
      title: 'منزل عائلي في دمشق القديمة',
      address: 'دمشق - حي الميدان',
      image: 'assets/images/house2.jpeg',
      price: 250000,
      beds: 5,
      baths: 2,
      area: 160,
      // 🚨 الوصف الثاني
      description: 'منزل عربي تقليدي تم ترميمه بالكامل، يحافظ على الطابع المعماري الدمشقي الأصيل مع إدخال لمسة عصرية. يضم فناءً داخلياً هادئاً ومساحة واسعة لاستقبال الضيوف.',
    ),
    // ... يرجى إضافة وصف لكل من المنازل المتبقية (house3, house4, house5)
    // لتجنب الأخطاء، سأكمل المنازل الثلاثة المتبقية الآن بوصف عام:
    House(
      title: 'شقة حديثة في مركز المدينة',
      address: 'حلب - حي الفرقان',
      image: 'assets/images/house3.jpeg',
      price: 130000,
      beds: 3,
      baths: 2,
      area: 145,
      description: 'شقة سكنية مريحة في منطقة حيوية وقريبة من جميع الخدمات. تتميز بتوزيع جيد للغرف وبلكون واسع وإضاءة طبيعية ممتازة.',
    ),
    House(
      title: 'فيلا مستقلة مع حديقة',
      address: 'حمص - حي الوعر',
      image: 'assets/images/house4.png',
      price: 310000,
      beds: 6,
      baths: 4,
      area: 350,
      description: 'فيلا بثلاثة طوابق، مجهزة بالكامل ومحاطة بحديقة خضراء مثالية للاسترخاء. تحتوي على مسبح خاص وغرف للمعيشة والترفيه في الطابق الأرضي.',
    ),
    House(
      title: 'شقة استثمارية قرب الجامعة',
      address: 'درعا - شارع الكورنيش',
      image: 'assets/images/house5.jpeg',
      price: 95000,
      beds: 2,
      baths: 1,
      area: 105,
      description: 'شقة صغيرة ومناسبة للطلاب أو للاستثمار المؤجر. موقعها ممتاز وقريب من المواصلات والأسواق الرئيسية. تحتاج لبعض التحديثات الطفيفة.',
    ),
  ].obs;
}